import { QuemSomos } from '../containers/quemSomos'

export default QuemSomos;
