import { Orcamento } from "../containers/orcamento";

export default Orcamento;
