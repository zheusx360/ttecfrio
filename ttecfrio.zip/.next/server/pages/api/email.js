"use strict";
(() => {
var exports = {};
exports.id = 846;
exports.ids = [846];
exports.modules = {

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 8809:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ sendEmail)
/* harmony export */ });
const nodemailer = __webpack_require__(5184);
async function sendEmail(req, res) {
    let transporter = nodemailer.createTransport({
        service: "Gmail",
        secure: true,
        auth: {
            user: "ttec.orcamento@gmail.com",
            pass: "ttec@2022"
        }
    });
    await transporter.sendMail({
        from: "ttec.orcamento@gmail.com",
        to: "ttec.orcamento@gmail.com",
        subject: "Nova solicita\xe7\xe3o de or\xe7amento",
        text: "",
        html: `<h3>Nome: ${req.body.nome}</h3></br><h3>Telefone: ${req.body.fone}</h3></br><h3>Email: ${req.body.email}</h3></br><h3>${req.body.data}</h3></br><h3>Mensagem: </h3></br><h3>${req.body.text}</h3>`
    }).then(res.status(200).json({
        message: "Email enviado com sucesso!"
    })).catch((error)=>res.status(500).json({
            message: `Erro ao enviar o email ${error}`
        })
    );
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8809));
module.exports = __webpack_exports__;

})();